Hello my name is Cutiey and this is my anti virus. Now as suspicious as batch files are, im no scriptor, not a coder or programmer. jus a nigga w a pc. but i did learn how simple code and file checks work. So heres my antivirus that i made in notepad and cmd with a smidge of python.. 

**MAKE SURE YOU OPEN THE .bat AS ADMINISTRATOR**